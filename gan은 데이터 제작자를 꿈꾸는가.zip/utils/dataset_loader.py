# utils/dataset_loader.py
# PNG 이미지 전용 커스텀 Dataset 정의 (torchvision.datasets.ImageFolder와 비슷하지만 PNG 전용)

import os
from PIL import Image
from torch.utils.data import Dataset

class PNGImageFolder(Dataset):
    def __init__(self, root, transform=None):
        """
        root: 이미지가 저장된 폴더 경로 (서브폴더 포함 가능)
        transform: 이미지 전처리 함수 (torchvision.transforms.Compose 형태)
        """
        self.root = root
        self.transform = transform

        # 폴더 내 모든 PNG 파일 경로를 리스트에 저장
        self.image_paths = []
        for dirpath, _, filenames in os.walk(root):
            for filename in filenames:
                if filename.lower().endswith(".png"):
                    self.image_paths.append(os.path.join(dirpath, filename))

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        # idx번째 이미지 불러오기
        img_path = self.image_paths[idx]
        img = Image.open(img_path).convert("RGB")  # PNG를 RGB로 변환

        if self.transform is not None:
            img = self.transform(img)

        return img, 0  # 라벨은 필요 없으므로 0으로 처리 (Dataloader 용)
