# models/discriminator.py
# Discriminator: 입력된 이미지가 진짜인지 가짜인지 판별하는 CNN 기반 분류기

import torch
import torch.nn as nn

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            # 입력: 3 x 256 x 256 (RGB 이미지)
            # 256x256x3 → 128x128x32
            nn.Conv2d(3, 32, kernel_size=4, stride=2, padding=1),
            nn.LeakyReLU(0.2, inplace=True),

            # 128x128x32 → 64x64x64
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),

            # 64x64x64 → 32x32x128
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),

            # 32x32x128 → 16x16x256
            nn.Conv2d(128, 256, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),

            # 16x16x256 → 8x8x512
            nn.Conv2d(256, 512, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),

            # 8x8x512 → 4x4x1024
            nn.Conv2d(512, 1024, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(1024),
            nn.LeakyReLU(0.2, inplace=True),

            # 4x4x1024 → Flatten
            nn.Flatten(),  # 4*4*1024 = 16384

            # 최종 출력: 1차원 스칼라 (진짜 확률)
            nn.Linear(4*4*1024, 1),
            nn.Sigmoid()  # 확률값 0~1 사이 출력
        )

    def forward(self, x):
        return self.model(x)
