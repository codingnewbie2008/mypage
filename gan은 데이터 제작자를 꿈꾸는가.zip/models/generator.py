# models/generator.py
# Generator: 잠재 벡터 z → 고해상도 이미지로 변환

import torch
import torch.nn as nn

class Generator(nn.Module):
    def __init__(self, z_dim):
        super().__init__()
        self.model = nn.Sequential(
            # z → 1024 x 4 x 4 feature map으로 변환
            nn.Linear(z_dim, 1024 * 4 * 4),
            nn.ReLU(True),
            nn.Unflatten(1, (1024, 4, 4)),

            # 4x4 → 8x8
            nn.ConvTranspose2d(1024, 512, 4, 2, 1),
            nn.InstanceNorm2d(512),
            nn.ReLU(True),

            # 8x8 → 16x16
            nn.ConvTranspose2d(512, 256, 4, 2, 1),
            nn.InstanceNorm2d(256),
            nn.ReLU(True),

            # 16x16 → 32x32
            nn.ConvTranspose2d(256, 128, 4, 2, 1),
            nn.InstanceNorm2d(128),
            nn.ReLU(True),

            # 32x32 → 64x64
            nn.ConvTranspose2d(128, 64, 4, 2, 1),
            nn.InstanceNorm2d(64),
            nn.ReLU(True),

            # 64x64 → 128x128
            nn.ConvTranspose2d(64, 32, 4, 2, 1),
            nn.InstanceNorm2d(32),
            nn.ReLU(True),

            # 128x128 → 256x256
            nn.ConvTranspose2d(32, 3, 4, 2, 1),
            nn.Tanh()  # 출력값 범위 [-1, 1]
        )

    def forward(self, z):
        return self.model(z)
