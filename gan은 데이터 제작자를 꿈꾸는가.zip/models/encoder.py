# models/encoder.py
# Encoder: 입력 이미지를 잠재 벡터 z로 변환하는 CNN 기반 인코더

import torch
import torch.nn as nn

class Encoder(nn.Module):
    def __init__(self, z_dim):
        super().__init__()
        self.model = nn.Sequential(
            # 256x256x3 → 128x128x64
            nn.Conv2d(3, 64, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),

            # 128x128x64 → 64x64x128
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),

            # 64x64x128 → 32x32x256
            nn.Conv2d(128, 256, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),

            # 32x32x256 → 16x16x512
            nn.Conv2d(256, 512, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),

            # 16x16x512 → 8x8x1024
            nn.Conv2d(512, 1024, kernel_size=4, stride=2, padding=1),
            nn.InstanceNorm2d(1024),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Flatten(),                         # 8*8*1024 = 65536
            nn.Linear(8*8*1024, z_dim),           # 잠재 벡터 z_dim 크기로 압축
            nn.Tanh()                             # z 벡터 값을 -1~1로 제한
        )

    def forward(self, x):
        return self.model(x)
