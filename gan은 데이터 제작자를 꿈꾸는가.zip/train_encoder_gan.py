# encoder_gan_project/train_encoder_gan.py
# Encoder-GAN 학습용 메인 파일

import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from torchvision import transforms
from models.encoder import Encoder
from models.generator import Generator
from models.discriminator import Discriminator
from utils.dataset_loader import PNGImageFolder

# ----------------------
# 🔧 하이퍼파라미터 설정
# ----------------------
image_size = 256
z_dim = 100
batch_size = 16
epochs = 5000

# 각 모듈 학습률 설정
lr_G = 0.00035
lr_D = 0.0001
lr_E = 0.0002

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ----------------------
# 📂 데이터 로딩
# ----------------------
data_transform = transforms.Compose([
    transforms.Resize(image_size),
    transforms.CenterCrop(image_size),
    transforms.ToTensor(),
    transforms.Normalize([0.5]*3, [0.5]*3)
])

dataset = PNGImageFolder(root="./train_images", transform=data_transform)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# ----------------------
# 🔧 모델 초기화
# ----------------------
E = Encoder(z_dim).to(device)
G = Generator(z_dim).to(device)
D = Discriminator().to(device)

# 손실함수
bce_loss = nn.BCELoss()
mse_loss = nn.MSELoss()

# 옵티마이저
opt_E = torch.optim.Adam(E.parameters(), lr=lr_E, betas=(0.5, 0.999))
opt_G = torch.optim.Adam(G.parameters(), lr=lr_G, betas=(0.5, 0.999))
opt_D = torch.optim.Adam(D.parameters(), lr=lr_D, betas=(0.5, 0.999))

# 저장 경로 생성
os.makedirs("./checkpoints", exist_ok=True)
os.makedirs("./generated_outputs", exist_ok=True)

# ----------------------
# 🔁 학습 루프 시작
# ----------------------
print("\n🚀 Training Start...")
for epoch in range(epochs):
    for i, (real_imgs, _) in enumerate(dataloader):
        real_imgs = real_imgs.to(device)
        bs = real_imgs.size(0)

        # -----------------------------
        # 1. 인코더 → z 생성
        # -----------------------------
        z = E(real_imgs)

        # -----------------------------
        # 2. Generator: z → 이미지 생성
        # -----------------------------
        fake_imgs = G(z)

        # -----------------------------
        # 3. Discriminator 학습
        # -----------------------------
        D_real = D(real_imgs)
        D_fake = D(fake_imgs.detach())

        real_labels = torch.full((bs, 1), 0.9, device=device)  # label smoothing 적용
        fake_labels = torch.zeros(bs, 1, device=device)

        d_loss_real = bce_loss(D_real, real_labels)
        d_loss_fake = bce_loss(D_fake, fake_labels)
        d_loss = (d_loss_real + d_loss_fake) / 2

        opt_D.zero_grad()
        d_loss.backward()
        opt_D.step()

        # -----------------------------
        # 4. Generator & Encoder 학습
        # -----------------------------
        D_fake = D(fake_imgs)
        g_adv_loss = bce_loss(D_fake, real_labels)         # Generator가 D를 속이려는 손실
        g_rec_loss = mse_loss(fake_imgs, real_imgs)        # 이미지 재구성 손실 (AE처럼)
        g_loss = g_adv_loss + 0.5 * g_rec_loss              # 가중치 조정 가능

        opt_E.zero_grad()
        opt_G.zero_grad()
        g_loss.backward()
        opt_E.step()
        opt_G.step()

        # -----------------------------
        # 5. 진행 상황 출력 및 저장
        # -----------------------------
        if i % 100 == 0:
            print(f"Epoch [{epoch+1}/{epochs}] Step [{i}]  D Loss: {d_loss.item():.4f} | G Loss: {g_loss.item():.4f}")
            save_image(fake_imgs[:8], f"./generated_outputs/gen_{epoch+1}_{i}.png", normalize=True, nrow=4)

# ----------------------
# 💾 학습된 모델 저장
# ----------------------
torch.save(G.state_dict(), "./checkpoints/generator.pth")
torch.save(E.state_dict(), "./checkpoints/encoder.pth")
torch.save(D.state_dict(), "./checkpoints/discriminator.pth")
print("\n✅ Training completed. Models saved to './checkpoints'")
