# test_from_image.py
# 학습된 Encoder와 Generator를 불러와서 외부 PNG 이미지를 입력받아 생성 이미지 출력

import os
import torch
from torchvision import transforms
from torchvision.utils import save_image
from PIL import Image

from models.encoder import Encoder
from models.generator import Generator

# 하이퍼파라미터
image_size = 256
z_dim = 100
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 이미지 전처리 (학습 시와 동일)
transform = transforms.Compose([
    transforms.Resize(image_size),
    transforms.CenterCrop(image_size),
    transforms.ToTensor(),
    transforms.Normalize([0.5]*3, [0.5]*3)
])

# 모델 초기화
encoder = Encoder(z_dim).to(device)
generator = Generator(z_dim).to(device)

# 학습된 가중치 불러오기
encoder.load_state_dict(torch.load("./checkpoints/encoder.pth", map_location=device))
generator.load_state_dict(torch.load("./checkpoints/generator.pth", map_location=device))

encoder.eval()
generator.eval()

# 테스트용 이미지 폴더 경로
test_img_dir = "./test_inputs"
output_dir = "./generated_outputs/test"
os.makedirs(output_dir, exist_ok=True)

# PNG 이미지 파일 리스트
test_images = [f for f in os.listdir(test_img_dir) if f.lower().endswith(".png")]

with torch.no_grad():
    for img_name in test_images:
        img_path = os.path.join(test_img_dir, img_name)
        img = Image.open(img_path).convert("RGB")
        input_tensor = transform(img).unsqueeze(0).to(device)  # 배치 차원 추가

        # Encoder로 잠재벡터 추출
        z = encoder(input_tensor)

        # Generator로 이미지 생성
        generated_img = generator(z)

        # 생성된 이미지 저장 (0~1 범위로 normalize)
        save_image(generated_img, os.path.join(output_dir, f"gen_{img_name}"), normalize=True)

        print(f"✅ Generated image saved: gen_{img_name}")

print("✅ 테스트 완료! generated_outputs/test 폴더에서 결과 확인하세요.")
